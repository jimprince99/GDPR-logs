#!/bin/bash
java -jar gdpr-logs.jar $* 

